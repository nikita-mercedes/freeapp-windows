"""FreeApp — локальная программа для Windows и Mac.

Запускает маленький сервер на этом же компьютере и открывает окно с интерфейсом.
Пароль от Apple ID вводится только здесь и уходит только в ipatool на этом же компьютере.
"""
import json
import os
import subprocess
import sys
import threading
import time
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

import urllib.request

# Сервер FreeApp: баланс установок и коды активации хранятся там, а не на компьютере клиента.
SERVER = "https://maritafreeapp.com"
BUY_URL = "https://t.me/maritafreeapp_bot"  # покупка пакетов установок в боте

IS_WIN = sys.platform == "win32"
IS_MAC = sys.platform == "darwin"

VERSION = "1.8.0"
# Номер последней версии лежит в репозитории сборок: если он больше нашего, в окне появляется плашка «Вышла новая версия».
VERSION_URL = "https://raw.githubusercontent.com/nikita-mercedes/freeapp-windows/main/version.txt"
UPDATE = {"latest": "", "checked": 0.0}

FROZEN = getattr(sys, "frozen", False)
BASE = Path(sys.executable).resolve().parent if FROZEN else Path(__file__).resolve().parent
UI = (Path(sys._MEIPASS) / "ui") if FROZEN else BASE / "ui"
# На Mac движок лежит в Contents/Resources: в Contents/MacOS посторонние файлы ломают подпись приложения.
ENGINE_DIR = (BASE.parent / "Resources" / "engine") if (IS_MAC and FROZEN) else (BASE / "engine")
ENGINE = ENGINE_DIR / ("ipatool.exe" if IS_WIN else "ipatool")
if IS_WIN:
    DATA = Path(os.environ.get("APPDATA", str(BASE))) / "FreeAPK"
elif IS_MAC:
    DATA = Path.home() / "Library" / "Application Support" / "FreeAPK"
else:
    DATA = Path.home() / ".freeapk"
DATA.mkdir(parents=True, exist_ok=True)
STATE_FILE = DATA / "state.json"
DOWNLOADS = DATA / "downloads"
DOWNLOADS.mkdir(exist_ok=True)
NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)

# Каталог приложений (App Store ID — публичные номера). Единый файл catalog.json лежит рядом с программой.
def load_catalog():
    here = (Path(sys._MEIPASS) if FROZEN else BASE) / "catalog.json"
    try:
        data = json.loads(here.read_text(encoding="utf-8-sig"))
        return [{"id": a["id"], "name": a["name"], "note": a.get("note", "")} for a in data if str(a.get("id", "")).isdigit()]
    except Exception:
        return [{"id": "310633997", "name": "WhatsApp", "note": "Соцсети и связь"}]


CATALOG = load_catalog()
LOG = []
LOCK = threading.Lock()
BUSY = {"on": False}


def say(text):
    with LOCK:
        LOG.append({"t": time.strftime("%H:%M:%S"), "text": text})
        del LOG[:-200]


def keychain_args():
    """Ключ для локального хранилища входа. Создаётся один раз и остаётся на этом компьютере."""
    f = DATA / "vault.key"
    if not f.exists():
        import secrets
        f.write_text(secrets.token_urlsafe(24), encoding="utf-8")
    return ["--keychain-passphrase", f.read_text(encoding="utf-8").strip()]


def device_id():
    """Случайный номер этого компьютера. К нему на сервере привязан баланс."""
    f = DATA / "device.id"
    try:
        v = f.read_text(encoding="utf-8").strip()
        if len(v) == 32 and all(c in "0123456789abcdef" for c in v):
            return v
    except Exception:
        pass
    import secrets
    v = secrets.token_hex(16)
    f.write_text(v, encoding="utf-8")
    return v


def fetch_text(url):
    try:
        req = urllib.request.Request(url, headers={"User-Agent": f"FreeApp/{VERSION}"})
        with urllib.request.urlopen(req, timeout=8) as r:
            return r.read().decode("utf-8").strip()
    except Exception:
        if not IS_MAC:
            return ""
    try:
        return subprocess.run(["/usr/bin/curl", "-sS", "-m", "8", url], capture_output=True, text=True, timeout=12).stdout.strip()
    except Exception:
        return ""


def version_tuple(v):
    try:
        return tuple(int(x) for x in v.split("."))
    except ValueError:
        return ()


def check_update():
    """Раз в час смотрит, не вышла ли версия новее этой."""
    if time.time() - UPDATE["checked"] < 3600:
        return
    UPDATE["checked"] = time.time()
    v = fetch_text(VERSION_URL)
    if version_tuple(v):
        UPDATE["latest"] = v


def update_loop():
    while True:
        check_update()
        time.sleep(3600)


def newer_version():
    latest = UPDATE["latest"]
    return latest if latest and version_tuple(latest) > version_tuple(VERSION) else ""


def ask_server(path, **payload):
    payload["device"] = device_id()
    body = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        SERVER + path, data=body,
        headers={"Content-Type": "application/json", "User-Agent": "FreeApp/1.2"})
    try:
        with urllib.request.urlopen(req, timeout=20) as r:
            return json.loads(r.read().decode("utf-8"))
    except Exception:
        if not IS_MAC:
            raise
    # На Mac у собранной программы нет списка сертификатов Python: просим системный curl, у него он есть.
    r = subprocess.run(
        ["/usr/bin/curl", "-sS", "-m", "20", "-X", "POST", "-H", "Content-Type: application/json",
         "-H", "User-Agent: FreeApp/1.2", "--data-binary", "@-", SERVER + path],
        input=body, capture_output=True, timeout=30)
    if r.returncode != 0:
        raise RuntimeError(r.stderr.decode("utf-8", "replace"))
    return json.loads(r.stdout.decode("utf-8"))


_bal = {"at": 0.0, "n": None}


def set_balance(n):
    _bal["n"] = n
    _bal["at"] = time.time()


def installs():
    """Баланс с сервера. Нет связи: показываем последнее известное число (или None)."""
    if _bal["n"] is not None and time.time() - _bal["at"] < 4:
        return _bal["n"]
    try:
        set_balance(ask_server("/api/device")["installs"])
    except Exception:
        _bal["at"] = time.time() - 2  # попробуем снова через пару секунд
    return _bal["n"]


def run(args, timeout=60):
    return subprocess.run(
        args, capture_output=True, text=True, timeout=timeout, stdin=subprocess.DEVNULL,
        creationflags=NO_WINDOW, encoding="utf-8", errors="replace",
    )


_device = {"at": 0, "value": False}


def device_connected():
    if time.time() - _device["at"] < 3:
        return _device["value"]
    try:
        if IS_WIN:
            cmd = ("Get-PnpDevice -PresentOnly | Where-Object { $_.FriendlyName -eq 'Apple iPhone' } "
                   "| Select-Object -First 1 -ExpandProperty FriendlyName")
            out = run(["powershell", "-NoProfile", "-Command", cmd], timeout=15).stdout.strip()
            _device["value"] = bool(out)
        else:
            tool = installer_path()
            _device["value"] = False
            if tool:
                out = run([str(tool), "usbmux", "list"], timeout=20).stdout
                try:
                    _device["value"] = bool(json.loads(out))
                except Exception:
                    _device["value"] = "serial" in out.lower()
    except Exception:
        _device["value"] = False
    _device["at"] = time.time()
    return _device["value"]


def installer_path():
    """Путь к модулю установки на iPhone (pymobiledevice3). Сейчас берётся из файла engine/pmd3-path.txt."""
    bundled = ENGINE_DIR / ("pmd3.exe" if IS_WIN else "pmd3" + os.sep + "pmd3")
    if bundled.exists():
        return bundled
    cfg = ENGINE_DIR / "pmd3-path.txt"
    try:
        p = Path(cfg.read_text(encoding="utf-8").strip())
        return p if p.exists() else None
    except Exception:
        return None


def engine_ready():
    return ENGINE.exists()


def account_email():
    if not engine_ready():
        return None
    try:
        r = run([str(ENGINE), "auth", "info", "--non-interactive", "--format", "json"] + keychain_args(), timeout=20)
        if r.returncode != 0:
            return None
        for line in (r.stdout + r.stderr).splitlines():
            try:
                d = json.loads(line)
            except Exception:
                continue
            if d.get("email"):
                return d["email"]
    except Exception:
        pass
    return None


def do_login(email, password, code):
    if not engine_ready():
        return False, "Не найден движок установки. Переустановите программу."
    say("Входим в Apple ID…")
    args = [str(ENGINE), "auth", "login", "--email", email, "--password", password, "--non-interactive"] + keychain_args()
    if code:
        args += ["--auth-code", code]
    try:
        r = run(args, timeout=300)
    except subprocess.TimeoutExpired:
        say("Apple долго не отвечает. Попробуйте позже.")
        return False, "Apple не отвечает больше 5 минут. Попробуйте позже."
    raw = (r.stdout + r.stderr)
    if password:
        raw = raw.replace(password, "***")
    (DATA / "last-login.txt").write_text(raw, encoding="utf-8")
    text = raw.lower()
    if r.returncode == 0:
        say("Вход выполнен.")
        return True, "ok"
    if "two-factor" in text or "2fa" in text or "auth code" in text or "code" in text:
        say("Apple просит код подтверждения. Введите его и нажмите «Войти» ещё раз.")
        return False, "need_code"
    if "429" in text or "rate" in text:
        say("Apple временно ограничил попытки входа. Подождите полчаса.")
        return False, "Apple временно ограничил попытки входа. Подождите полчаса и повторите."
    if "404" in text:
        say("Эта версия движка устарела: Apple больше не принимает такой вход.")
        return False, "Движок входа устарел. Нужно обновление программы."
    say("Не удалось войти. Причина сохранена в файл для разработчика.")
    return False, "Не удалось войти. Если пароль верный, напишите в поддержку."


def do_logout():
    if not engine_ready():
        return False, "Не найден движок установки."
    try:
        r = run([str(ENGINE), "auth", "revoke", "--non-interactive"] + keychain_args(), timeout=30)
    except Exception:
        return False, "Не удалось выйти. Попробуйте ещё раз."
    if r.returncode == 0:
        say("Вы вышли из Apple ID.")
        return True, "ok"
    return False, "Не удалось выйти. Попробуйте ещё раз."


def do_redeem(code):
    try:
        d = ask_server("/api/redeem", code=code)
    except Exception:
        say("Нет связи с сервером.")
        return False, "Нет связи с сервером. Проверьте интернет и повторите."
    if "installs" in d:
        set_balance(d["installs"])
    if d.get("ok"):
        say(f"Код принят. Добавлено установок: {d.get('added', 0)}.")
    else:
        say("Код не принят.")
    return bool(d.get("ok")), d.get("message", "Код не подошёл.")


def do_install(app_id):
    ticket = None
    done = False
    try:
        BUSY["on"] = True
        if not device_connected():
            say("iPhone не найден. Подключите телефон кабелем и разблокируйте его.")
            return
        if not account_email():
            say("Сначала войдите в Apple ID.")
            return
        # Установка списывается на сервере до начала. Если что-то пойдёт не так, она вернётся.
        try:
            s = ask_server("/api/spend")
        except Exception:
            say("Нет связи с сервером. Проверьте интернет и повторите.")
            return
        if not s.get("ok"):
            say(s.get("message") or "Установки закончились. Пополните баланс в боте.")
            return
        ticket = s["ticket"]
        set_balance(s["installs"])
        say(f"Скачиваем приложение {app_id}…")
        out = DOWNLOADS / app_id
        out.mkdir(exist_ok=True)
        try:
            r = run([str(ENGINE), "download", "-i", app_id, "-o", str(out), "--purchase", "--non-interactive"] + keychain_args(), timeout=600)
        except subprocess.TimeoutExpired:
            say("Скачивание слишком долгое.")
            return
        if r.returncode != 0:
            raw = r.stdout + r.stderr
            (DATA / "last-download.txt").write_text(raw, encoding="utf-8")
            low = raw.lower()
            if "license" in low or "price" in low or "purchase" in low or "unavailable" in low:
                say("App Store не выдал это приложение вашему Apple ID. Его уже нет в магазине вашей страны: оно ставится только с аккаунта, где было скачано раньше.")
            elif "password token" in low or "login" in low:
                say("Нужно заново войти в Apple ID: нажмите «Выйти» и войдите снова.")
            else:
                say("Не получилось скачать.")
            return
        say("Приложение скачано.")
        ipas = sorted(out.glob("*.ipa"), key=lambda p: p.stat().st_mtime, reverse=True)
        tool = installer_path()
        if not ipas or not tool:
            say("Не найден модуль установки на iPhone.")
            return
        say("Ставим на iPhone. Не отключайте кабель и не блокируйте экран…")
        try:
            r = run([str(tool), "apps", "install", str(ipas[0])], timeout=600)
        except subprocess.TimeoutExpired:
            say("Установка заняла слишком долго.")
            return
        if r.returncode == 0 and "installation succeed" in (r.stdout + r.stderr).lower():
            done = True
            say(f"Готово: приложение установлено. Осталось установок: {s['installs']}.")
        else:
            raw = (r.stdout + r.stderr).lower()
            if "trust" in raw or "pair" in raw:
                say("Телефон не доверяет компьютеру. Разблокируйте iPhone и нажмите «Доверять».")
            elif "device not found" in raw or "usbmux" in raw:
                say("iPhone отключился или заблокировался. Подключите кабель, разблокируйте телефон и повторите.")
            else:
                say("Не получилось установить.")
            (DATA / "last-install.txt").write_text(r.stdout + r.stderr, encoding="utf-8")
    finally:
        if ticket and not done:
            try:
                rf = ask_server("/api/refund", ticket=ticket)
                if "installs" in rf:
                    set_balance(rf["installs"])
                say("Установка возвращена на баланс.")
            except Exception:
                say("Не удалось вернуть установку: нет связи с сервером. Напишите в поддержку.")
        BUSY["on"] = False

class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def send_json(self, obj, code=200):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        p = self.path.split("?")[0]
        if p == "/api/status":
            self.send_json({
                "device": device_connected(),
                "email": account_email(),
                "installs": installs(),
                "busy": BUSY["on"],
                "version": VERSION,
                "update": newer_version(),
            })
        elif p == "/api/ping":
            self.send_json({"app": "freeapp"})
        elif p == "/api/catalog":
            self.send_json(CATALOG)
        elif p == "/api/log":
            with LOCK:
                self.send_json(LOG)
        else:
            f = UI / ("index.html" if p == "/" else p.lstrip("/"))
            if f.is_file() and UI.resolve() in f.resolve().parents:
                data = f.read_bytes()
                self.send_response(200)
                self.send_header("Content-Type", {".html": "text/html; charset=utf-8", ".svg": "image/svg+xml"}.get(f.suffix, "text/plain"))
                self.send_header("Content-Length", str(len(data)))
                self.end_headers()
                self.wfile.write(data)
            else:
                self.send_json({"error": "not found"}, 404)

    def do_POST(self):
        n = int(self.headers.get("Content-Length", 0))
        try:
            data = json.loads(self.rfile.read(n) or b"{}")
        except Exception:
            data = {}
        if self.path == "/api/login":
            ok, msg = do_login(str(data.get("email", "")).strip(), str(data.get("password", "")), str(data.get("code", "")).strip())
            self.send_json({"ok": ok, "message": msg})
        elif self.path == "/api/logout":
            ok, msg = do_logout()
            self.send_json({"ok": ok, "message": msg})
        elif self.path == "/api/open":
            try:
                if IS_WIN:
                    os.startfile(BUY_URL)
                else:
                    webbrowser.open(BUY_URL)
                self.send_json({"ok": True})
            except Exception:
                self.send_json({"ok": False, "message": "Не удалось открыть Telegram. Откройте t.me/maritafreeapp_bot вручную."})
        elif self.path == "/api/site":
            try:
                if IS_WIN:
                    os.startfile(SERVER)
                else:
                    webbrowser.open(SERVER)
                self.send_json({"ok": True})
            except Exception:
                self.send_json({"ok": False})
        elif self.path == "/api/redeem":
            ok, msg = do_redeem(str(data.get("code", "")))
            self.send_json({"ok": ok, "message": msg})
        elif self.path == "/api/install":
            app_id = "".join(c for c in str(data.get("id", "")) if c.isdigit())
            if not app_id:
                self.send_json({"ok": False, "message": "Введите номер приложения цифрами."})
            elif BUSY["on"]:
                self.send_json({"ok": False, "message": "Подождите, идёт другая установка."})
            else:
                threading.Thread(target=do_install, args=(app_id,), daemon=True).start()
                self.send_json({"ok": True})
        else:
            self.send_json({"error": "not found"}, 404)


def open_window(url):
    """Открывает программу отдельным окном без адресной строки; если подходящего браузера нет, обычной вкладкой."""
    edge = r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"
    if IS_WIN and os.path.exists(edge):
        subprocess.Popen([edge, f"--app={url}", "--window-size=1100,720"])
        return
    if IS_MAC:
        homes = ["/Applications", os.path.expanduser("~/Applications")]
        for name in ("Google Chrome", "Microsoft Edge", "Brave Browser", "Chromium"):
            for home in homes:
                exe = f"{home}/{name}.app/Contents/MacOS/{name}"
                if os.path.exists(exe):
                    try:
                        subprocess.Popen([exe, f"--app={url}", "--window-size=1100,720"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                        return
                    except OSError:
                        pass
    webbrowser.open(url)


def main():
    port = 8765
    server = None
    if not IS_WIN:
        # Уже запущена? Тогда просто открываем окно браузера с ней, а второй сервер не поднимаем.
        for p in range(port, port + 20):
            try:
                with urllib.request.urlopen(f"http://127.0.0.1:{p}/api/ping", timeout=0.7) as r:
                    if json.loads(r.read().decode("utf-8")).get("app") == "freeapp":
                        open_window(f"http://127.0.0.1:{p}/")
                        return
            except Exception:
                continue
    for p in range(port, port + 20):
        try:
            server = ThreadingHTTPServer(("127.0.0.1", p), Handler)
            port = p
            break
        except OSError:
            continue
    if server is None:
        print("Не удалось открыть порт.")
        sys.exit(1)
    open_window(f"http://127.0.0.1:{port}/")
    threading.Thread(target=update_loop, daemon=True).start()
    say("Программа запущена.")
    server.serve_forever()


if __name__ == "__main__":
    main()
