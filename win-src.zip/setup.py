import os, sys, time, shutil, zipfile, ctypes, subprocess
from pathlib import Path

NOWIN = 0x08000000

def box(text, flags=0x40):
    ctypes.windll.user32.MessageBoxW(0, text, "FreeApp", flags)

def have_apple():
    r = subprocess.run(["powershell", "-NoProfile", "-Command",
                        "Get-AppxPackage -Name '*AppleInc*' -ErrorAction SilentlyContinue | Select-Object -First 1 -ExpandProperty Name"],
                       capture_output=True, text=True, creationflags=NOWIN, stdin=subprocess.DEVNULL)
    if r.stdout.strip():
        return True
    pf = os.environ.get("CommonProgramFiles", r"C:\Program Files\Common Files")
    return os.path.exists(os.path.join(pf, "Apple", "Mobile Device Support"))


def main():
    base = Path(getattr(sys, "_MEIPASS", Path(__file__).parent))
    dest = Path(os.environ["LOCALAPPDATA"]) / "FreeApp"
    subprocess.run(["taskkill", "/F", "/IM", "FreeApp.exe"], capture_output=True, creationflags=NOWIN, stdin=subprocess.DEVNULL)
    time.sleep(1)
    if dest.exists():
        shutil.rmtree(dest, ignore_errors=True)
    dest.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(base / "payload.zip") as z:
        z.extractall(dest)
    exe = dest / "FreeApp" / "FreeApp.exe"
    ps = ('$d=[Environment]::GetFolderPath("Desktop");'
          '$s=(New-Object -ComObject WScript.Shell).CreateShortcut("$d\\FreeApp.lnk");'
          f'$s.TargetPath="{exe}";$s.WorkingDirectory="{exe.parent}";$s.IconLocation="{exe},0";$s.Save()')
    subprocess.run(["powershell", "-NoProfile", "-Command", ps], capture_output=True, creationflags=NOWIN, stdin=subprocess.DEVNULL)
    subprocess.Popen([str(exe)], cwd=str(exe.parent), stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    if not have_apple():
        box("FreeApp установлен и запущен.\n\nЧтобы компьютер видел ваш iPhone, нужна бесплатная программа Apple Devices из Microsoft Store "
            "(или iTunes). Сейчас откроется Microsoft Store: нажмите «Получить» и подключите iPhone кабелем.")
        os.startfile("ms-windows-store://search/?query=Apple%20Devices")

if __name__ == "__main__":
    try:
        main()
    except Exception:
        box("Не удалось установить FreeApp. Закройте программу, если она открыта, и запустите установщик ещё раз.", 0x10)
        sys.exit(1)